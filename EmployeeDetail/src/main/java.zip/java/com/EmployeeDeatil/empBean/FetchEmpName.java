package com.EmployeeDeatil.empBean;

public class FetchEmpName {

	private Long empId;
	private String first_nm;
	private String middle_nm;
	private String last_nm;
	
	
	public Long getEmpId() {
		return empId;
	}
	public void setEmpId(Long empId) {
		this.empId = empId;
	}
	public String getFirst_nm() {
		return first_nm;
	}
	public void setFirst_nm(String first_nm) {
		this.first_nm = first_nm;
	}
	public String getMiddle_nm() {
		return middle_nm;
	}
	public void setMiddle_nm(String middle_nm) {
		this.middle_nm = middle_nm;
	}
	public String getLast_nm() {
		return last_nm;
	}
	public void setLast_nm(String last_nm) {
		this.last_nm = last_nm;
	}
	
	
	
}
